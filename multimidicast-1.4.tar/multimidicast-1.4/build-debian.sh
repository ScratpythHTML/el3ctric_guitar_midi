#!/bin/sh
apt-get -y install build-essential libasound2-dev
make install
